<?php
/**
 * Debasish Das — Web Studio & Store · XAMPP PHP backend
 * Apache + PHP 8 + MySQL/MariaDB via PDO.
 * The JSON API is versioned in lockstep with the frontend.
 * frontend JS works unchanged.
 */
declare(strict_types=1);

define('DD_ROOT', dirname(__DIR__));
define('DD_DATA', ($__dd = getenv('DD_DATA_DIR')) !== false && $__dd !== '' ? rtrim(str_replace('\\', '/', $__dd), '/') : DD_ROOT . '/data');
define('DD_MAX_JSON_BYTES', 120 * 1024);

/* ════════════════ paths & environment ════════════════ */
function dd_mkdir_data(): void {
  if (!is_dir(DD_DATA)) @mkdir(DD_DATA, 0775, true);
  // keep the database out of the web root on Apache hosts
  $guard = DD_DATA . '/.htaccess';
  if (!is_file($guard)) @file_put_contents($guard, "Require all denied\n\n# Apache 2.2\n<IfModule !mod_authz_core.c>\nOrder deny,allow\nDeny from all\n</IfModule>\n");
}
dd_mkdir_data();

function dd_read_install(): array {
  $f = DD_DATA . '/install.json';
  if (!is_file($f)) return [];
  $j = json_decode((string) @file_get_contents($f), true);
  return is_array($j) ? $j : [];
}
function dd_write_install(array $obj): void {
  $path = DD_DATA . '/install.json';
  $json = json_encode($obj, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
  if ($json === false || file_put_contents($path, $json, LOCK_EX) === false) {
    throw new RuntimeException('Could not save setup credentials. Check that the data folder is writable.');
  }
  @chmod($path, 0600);
}

/* ════════════════ errors ════════════════ */
class DdHttpError extends Exception {
  public int $status;
  public function __construct(int $status, string $message) {
    parent::__construct($message);
    $this->status = $status;
  }
}

/* ════════════════ database ════════════════ */
function dd_mysql_config(array $input): array {
  $host = trim((string) ($input['host'] ?? ''));
  $database = trim((string) ($input['database'] ?? ''));
  $username = trim((string) ($input['username'] ?? ''));
  $password = (string) ($input['password'] ?? '');
  $port = filter_var($input['port'] ?? 3306, FILTER_VALIDATE_INT);
  if (!preg_match('/^[A-Za-z0-9.:-]{1,253}$/', $host)) throw new DdHttpError(400, 'Enter a valid MySQL host name or IP address');
  if (!preg_match('/^[A-Za-z0-9_$-]{1,64}$/', $database)) throw new DdHttpError(400, 'Enter the existing database name');
  if (!preg_match('/^[A-Za-z0-9_.@-]{1,128}$/', $username)) throw new DdHttpError(400, 'Enter the MySQL username');
  if ($port === false || $port < 1 || $port > 65535) throw new DdHttpError(400, 'Enter a valid MySQL port');
  if (strlen($password) > 256) throw new DdHttpError(400, 'The MySQL password is too long');
  return ['host' => $host, 'database' => $database, 'username' => $username, 'password' => $password, 'port' => $port];
}

function dd_mysql_connect(array $config): PDO {
  $config = dd_mysql_config($config);
  $dsn = "mysql:host={$config['host']};port={$config['port']};dbname={$config['database']};charset=utf8mb4";
  return new PDO($dsn, $config['username'], $config['password'], [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
  ]);
}

final class DdDb {
  public static ?PDO $pdo = null;
  public static array $config = [];

  public static function open(array $config): void {
    self::$config = dd_mysql_config($config);
    self::$pdo = dd_mysql_connect(self::$config);
    self::ensureSchema();
    self::runMigrations();
  }

  public static function close(): void {
    self::$pdo = null;
  }

  public static function pdo(): PDO {
    if (!self::$pdo) {
      $install = dd_read_install();
      if (!isset($install['database']) || !is_array($install['database'])) {
        throw new DdHttpError(503, 'MySQL is not configured. Open setup.html and enter your database credentials.');
      }
      self::open($install['database']);
    }
    return self::$pdo;
  }

  private static function ensureSchema(): void {
    $schemas = [
      "CREATE TABLE IF NOT EXISTS users (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(80) NOT NULL,
        username VARCHAR(64) NOT NULL,
        email VARCHAR(190) NOT NULL,
        phone VARCHAR(32) NOT NULL DEFAULT '',
        password_hash VARCHAR(255) NOT NULL,
        password_salt VARCHAR(32) NOT NULL DEFAULT 'bcrypt',
        role VARCHAR(16) NOT NULL DEFAULT 'user',
        email_otp_hash VARCHAR(255) NULL,
        email_otp_expires_at DATETIME NULL,
        email_otp_attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_users_username (username),
        UNIQUE KEY uq_users_email (email)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
      "CREATE TABLE IF NOT EXISTS sessions (
        token CHAR(64) NOT NULL PRIMARY KEY,
        user_id BIGINT UNSIGNED NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        expires_at DATETIME NOT NULL,
        KEY idx_sessions_user (user_id),
        CONSTRAINT fk_sessions_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
      "CREATE TABLE IF NOT EXISTS products (
        id VARCHAR(64) NOT NULL PRIMARY KEY,
        name VARCHAR(190) NOT NULL,
        meta VARCHAR(255) NOT NULL DEFAULT '',
        tag VARCHAR(80) NOT NULL DEFAULT 'Tech',
        price BIGINT NOT NULL DEFAULT 0,
        was BIGINT NOT NULL DEFAULT 0,
        rating DECIMAL(3,2) NOT NULL DEFAULT 4.5,
        stock INT NOT NULL DEFAULT 10,
        img VARCHAR(255) NOT NULL DEFAULT 'assets/img/product-mouse.jpg',
        active TINYINT(1) NOT NULL DEFAULT 1,
        reviews INT NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        KEY idx_products_active (active)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
      "CREATE TABLE IF NOT EXISTS orders (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        user_id BIGINT UNSIGNED NULL,
        customer_name VARCHAR(120) NOT NULL,
        phone VARCHAR(32) NOT NULL DEFAULT '',
        address TEXT NOT NULL,
        note TEXT NOT NULL,
        items_json MEDIUMTEXT NOT NULL,
        total BIGINT NOT NULL DEFAULT 0,
        payment VARCHAR(16) NOT NULL DEFAULT 'cod',
        coupon_code VARCHAR(20) NOT NULL DEFAULT '',
        discount BIGINT NOT NULL DEFAULT 0,
        delivery_method VARCHAR(16) NOT NULL DEFAULT 'standard',
        status VARCHAR(16) NOT NULL DEFAULT 'pending',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        KEY idx_orders_user (user_id),
        KEY idx_orders_status (status),
        KEY idx_orders_created (created_at),
        CONSTRAINT fk_orders_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
      "CREATE TABLE IF NOT EXISTS addresses (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        user_id BIGINT UNSIGNED NOT NULL,
        label VARCHAR(24) NOT NULL DEFAULT 'Home',
        name VARCHAR(120) NOT NULL,
        phone VARCHAR(32) NOT NULL,
        line VARCHAR(255) NOT NULL,
        city VARCHAR(100) NOT NULL DEFAULT '',
        state VARCHAR(100) NOT NULL DEFAULT '',
        pincode VARCHAR(20) NOT NULL DEFAULT '',
        is_default TINYINT(1) NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        KEY idx_addresses_user (user_id),
        CONSTRAINT fk_addresses_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
      "CREATE TABLE IF NOT EXISTS inquiries (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(120) NOT NULL,
        phone VARCHAR(32) NOT NULL DEFAULT '',
        need VARCHAR(160) NOT NULL DEFAULT '',
        budget VARCHAR(80) NOT NULL DEFAULT '',
        message TEXT NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
      "CREATE TABLE IF NOT EXISTS coupons (
        code VARCHAR(20) NOT NULL PRIMARY KEY,
        type VARCHAR(16) NOT NULL DEFAULT 'percent',
        value BIGINT NOT NULL DEFAULT 1,
        min_order BIGINT NOT NULL DEFAULT 0,
        active TINYINT(1) NOT NULL DEFAULT 1,
        used BIGINT NOT NULL DEFAULT 0,
        max_uses BIGINT NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
      "CREATE TABLE IF NOT EXISTS store_settings (
        `key` VARCHAR(80) NOT NULL PRIMARY KEY,
        value TEXT NOT NULL
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
      "CREATE TABLE IF NOT EXISTS reviews (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        product_id VARCHAR(64) NOT NULL,
        user_id BIGINT UNSIGNED NULL,
        name VARCHAR(120) NOT NULL DEFAULT 'Customer',
        rating TINYINT UNSIGNED NOT NULL,
        title VARCHAR(80) NOT NULL DEFAULT '',
        body TEXT NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_review_user (product_id, user_id),
        KEY idx_reviews_product (product_id),
        CONSTRAINT fk_reviews_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
        CONSTRAINT fk_reviews_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    ];
    foreach ($schemas as $schema) self::$pdo->exec($schema);
  }

  private static function runMigrations(): void {
    $columns = static function (string $table): array {
      $stmt = self::$pdo->prepare('SHOW COLUMNS FROM `' . $table . '`');
      $stmt->execute();
      return array_column($stmt->fetchAll(), 'Field');
    };
    $users = $columns('users');
    if (!in_array('username', $users, true)) {
      self::$pdo->exec('ALTER TABLE users ADD COLUMN username VARCHAR(64) NULL AFTER name');
      self::$pdo->exec("UPDATE users SET username = CONCAT('user', id) WHERE username IS NULL OR username = ''");
      self::$pdo->exec('ALTER TABLE users MODIFY username VARCHAR(64) NOT NULL');
      self::$pdo->exec('ALTER TABLE users ADD UNIQUE KEY uq_users_username (username)');
    }
    $users = $columns('users');
    if (!in_array('email_otp_hash', $users, true)) self::$pdo->exec('ALTER TABLE users ADD COLUMN email_otp_hash VARCHAR(255) NULL');
    if (!in_array('email_otp_expires_at', $users, true)) self::$pdo->exec('ALTER TABLE users ADD COLUMN email_otp_expires_at DATETIME NULL');
    if (!in_array('email_otp_attempts', $users, true)) self::$pdo->exec('ALTER TABLE users ADD COLUMN email_otp_attempts TINYINT UNSIGNED NOT NULL DEFAULT 0');
  }
}

function dd_db(): PDO { return DdDb::pdo(); }
function dd_db_info(): array {
  $config = DdDb::$config ?: (dd_read_install()['database'] ?? []);
  $counts = [];
  foreach (['users', 'products', 'orders', 'reviews', 'coupons', 'inquiries'] as $table) {
    $counts[$table] = (int) dd_db()->query("SELECT COUNT(*) FROM `$table`")->fetchColumn();
  }
  return [
    'engine' => 'MySQL / MariaDB',
    'host' => (string) ($config['host'] ?? ''),
    'database' => (string) ($config['database'] ?? ''),
    'username' => (string) ($config['username'] ?? ''),
    'port' => (int) ($config['port'] ?? 3306),
    'counts' => $counts,
  ];
}
