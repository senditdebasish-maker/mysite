# mysite — XAMPP install

A PHP/MySQL storefront and account system for Apache in XAMPP. Includes product pages,
checkout, customer accounts, order tracking, admin tools, invoices, and a first-run setup
wizard. There is no Node build step.

## Requirements

- Windows with XAMPP (Apache, MySQL/MariaDB, PHP 8.x)
- PHP extensions `pdo_mysql`, `mbstring`, and `openssl`
- Composer dependencies installed in the project folder (`composer install`)
- A MySQL database and user that you have already created or that your provider assigned
- A Gmail account with 2-Step Verification and a Google App Password for email OTP

## Install

1. Copy the project to `C:\xampp\htdocs\mysite`.
2. Start **Apache** and **MySQL** in the XAMPP Control Panel.
3. Open `http://localhost/phpmyadmin/` and create a database and a MySQL user for this
   site. Grant that user access to the site database. If a live provider already created
   the database for you, use the exact host, database name, username, password, and port
   they supplied instead. The installer does not create or delete databases.
4. Install PHPMailer in the project folder:

   ```powershell
   cd C:\xampp\htdocs\mysite
   composer install
   ```

   If Composer reports that ZIP support is missing, enable `extension=zip` in
   `C:\xampp\php\php.ini`, restart Apache, and retry.
5. Open `http://localhost/mysite/setup.html`.
6. Enter the existing MySQL connection details and use **Test connection**, then
   **Connect & prepare tables**. This creates the application's tables inside that
   database; the MySQL user needs table-creation privileges.
7. Enter the Gmail address and its App Password and press **Save & test Gmail**. Google
   App Passwords are created in your Google Account after enabling 2-Step Verification;
   do not enter your normal Gmail password.
8. Set your site identity, create your own admin username and password, configure the
   storefront, and press **Complete setup**.

The database and Gmail credentials are kept in `data/install.json`. The `data/` folder is
blocked by Apache rules; keep those rules in place and never publish this file or commit
it to source control. The local SQLite database from older versions is not imported.

## Sign-in

The login page offers both:

- **Username/email + password**
- **Email OTP** — sends a single-use six-digit code to the account email via Gmail SMTP;
  the code expires after 10 minutes and is limited to five verification attempts.

New customer accounts require a unique username, email, and password. Admin credentials
are created in the setup wizard; there are no built-in admin/customer demo accounts or
credential-fill buttons.

## Database backups

Use phpMyAdmin to export the database before making changes and to import a backup:
select the site's database, then choose **Export** or **Import**. The setup page links
to phpMyAdmin and includes the same instructions.

## XAMPP routing

The root `.htaccess` routes pages and `/api/*` requests through PHP. Keep Apache's
`mod_rewrite` enabled and keep the project `.htaccess` file. Open the site using its
Apache URL (`http://localhost/mysite/`), not by opening the HTML files directly.

## Main project files

| Path | Purpose |
| --- | --- |
| `setup.html` | MySQL, Gmail SMTP, admin, identity, and storefront setup |
| `login.html` | Password and email OTP sign-in; account registration |
| `api/index.php` | PHP JSON API, authentication, setup, checkout, admin routes |
| `api/lib.php` | MySQL connection, schema, and migrations |
| `api/core.php` | Sessions, settings, password hashing, and shared helpers |
| `api/seed.php` | Optional sample product catalogue and storefront defaults |
| `data/` | Protected installer credentials and request-throttle data |
| `vendor/` | Composer dependencies, including PHPMailer |

