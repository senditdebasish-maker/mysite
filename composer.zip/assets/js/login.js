/* /login.html — password and email OTP sign-in */
(function () {
  const $ = (s) => document.querySelector(s);
  const params = new URLSearchParams(location.search);
  const rawNext = params.get("next") || "";
  const next = /^[\w./-]+\.html(\?.*)?$/.test(rawNext) && !rawNext.includes("..") ? rawNext : null;

  const heading = $("#authHeading"), cardSub = $("#authCardSub"), errEl = $("#authError");
  const tabLogin = $("#tabLogin"), tabRegister = $("#tabRegister");
  const passwordTab = $("#loginPasswordTab"), otpTab = $("#loginOtpTab");
  const passwordForm = $("#formLogin"), otpForm = $("#formOtp"), formRegister = $("#formRegister");
  const showError = (msg) => { errEl.textContent = msg || ""; };
  let method = "password";

  const setMethod = (value) => {
    method = value;
    const password = value === "password";
    passwordTab.classList.toggle("is-active", password);
    otpTab.classList.toggle("is-active", !password);
    passwordTab.setAttribute("aria-selected", String(password));
    otpTab.setAttribute("aria-selected", String(!password));
    passwordForm.dataset.hidden = String(!password);
    otpForm.dataset.hidden = String(password);
    $("#otp-code-label").hidden = true;
    $("#otp-submit").hidden = true;
    $("#otp-code").value = "";
    showError("");
  };

  const setMode = (mode) => {
    const login = mode === "login";
    tabLogin.classList.toggle("is-active", login);
    tabRegister.classList.toggle("is-active", !login);
    tabLogin.setAttribute("aria-selected", String(login));
    tabRegister.setAttribute("aria-selected", String(!login));
    passwordForm.dataset.hidden = String(!login || method !== "password");
    otpForm.dataset.hidden = String(!login || method !== "otp");
    formRegister.dataset.hidden = String(login);
    passwordTab.closest(".auth-tabs").hidden = !login;
    heading.textContent = login ? "Welcome back" : "Create your account";
    cardSub.textContent = login
      ? "Sign in with your username and password, or get a code by email."
      : "Create an account to track orders and get priority support.";
    showError("");
  };

  tabLogin.addEventListener("click", () => setMode("login"));
  tabRegister.addEventListener("click", () => setMode("register"));
  passwordTab.addEventListener("click", () => setMethod("password"));
  otpTab.addEventListener("click", () => setMethod("otp"));
  if (location.hash === "#create") setMode("register");

  const destFor = (user) => next || (user.role === "admin" ? "admin.html" : "dashboard.html");
  const signIn = (user) => { location.href = destFor(user); };
  const otpIdentifier = () => $("#otp-identifier").value.trim();

  passwordForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    showError("");
    const btn = $("#li-submit"); btn.disabled = true; btn.textContent = "Signing in…";
    try {
      const data = await window.UI.fetchJSON("api/auth/login", {
        method: "POST",
        body: JSON.stringify({ identifier: $("#li-identifier").value, password: $("#li-password").value }),
      });
      signIn(data.user);
    } catch (err) {
      showError(err.message);
      btn.disabled = false; btn.textContent = "Sign in →";
    }
  });

  $("#otp-send").addEventListener("click", async () => {
    showError("");
    const btn = $("#otp-send"); btn.disabled = true; btn.textContent = "Sending…";
    try {
      const data = await window.UI.fetchJSON("api/auth/otp/request", {
        method: "POST", body: JSON.stringify({ identifier: otpIdentifier() }),
      });
      $("#otp-code-label").hidden = false;
      $("#otp-submit").hidden = false;
      showError(data.message || "If the account exists, a sign-in code has been sent.");
    } catch (err) {
      showError(err.message);
    } finally {
      btn.disabled = false; btn.textContent = "Send email code";
    }
  });

  otpForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    showError("");
    const btn = $("#otp-submit"); btn.disabled = true; btn.textContent = "Verifying…";
    try {
      const data = await window.UI.fetchJSON("api/auth/otp/verify", {
        method: "POST",
        body: JSON.stringify({ identifier: otpIdentifier(), code: $("#otp-code").value }),
      });
      signIn(data.user);
    } catch (err) {
      showError(err.message);
      btn.disabled = false; btn.textContent = "Verify code →";
    }
  });

  formRegister.addEventListener("submit", async (e) => {
    e.preventDefault();
    showError("");
    const btn = $("#re-submit"); btn.disabled = true; btn.textContent = "Creating…";
    try {
      const data = await window.UI.fetchJSON("api/auth/register", {
        method: "POST",
        body: JSON.stringify({
          name: $("#re-name").value, username: $("#re-username").value,
          email: $("#re-email").value, phone: $("#re-phone").value,
          password: $("#re-password").value,
        }),
      });
      signIn(data.user);
    } catch (err) {
      showError(err.message);
      btn.disabled = false; btn.textContent = "Create account →";
    }
  });

  (async () => {
    try {
      const res = await fetch("api/me");
      const data = await res.json();
      if (data.user) location.replace(destFor(data.user));
    } catch { /* Stay on the sign-in page when the API is unavailable. */ }
  })();
})();
